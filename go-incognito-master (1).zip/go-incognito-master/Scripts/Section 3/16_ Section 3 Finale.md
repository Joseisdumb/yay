# Section 3 Finale

This has been a long journey so far...but we’re only halfway through the entire
course. I’m sure this is a lot of information, but I hope you’re absorbing it and
utilizing a lot of what’s discussed

In this section, we went over Basic Digital Protection, which is a very broad topic.
Keeping software up-to-date, minimizing permissions and settings granted to
apps and programs, passwords and two-factor authentication, privacy-oriented
search engines, private and secure web browsers, how to harden web browsers,
proper browsing habits, and a lesson on browser uniqueness. Don’t forget about
proxies and VPNs, antiviruses and malware, shredding files, proper storage and
encryption, and lastly: safe communication. Whoo! That’s a lot of stuff.

Since this course is free, I’m asking you to consider helping out the channel, and
the course. You can do that by using our Amazon affiliate link anytime you buy
something on Amazon, you can donate through cryptocurrency on our support
page, as well as other affiliate links there, you can purchase some awesome
merch, and don’t forget there will be a premium version of the course on Udemy
that gives you quizzes, tests, checklists, and an ad-free experience! You can find
all of the support methods on the channel website.

Lastly, your support and part of the community is enormously important So don’t
forget to subscribe to the channel on YouTube, share the course and the
channel with your friends, and make sure to follow us on social media. Not only
does this support our work and the course, but it allows me to send all of you
updates if anything in the course becomes outdated.

Thank you in advance for being a premium viewer, you really are an important
part of what’s keeping this course alive. You’re halfway through, so I want to
congratulate you! Section 3 is the most information-packed section of the course
so from here on out--it should hopefully be smooth sailing.

Thanks again to everybody watching, and I’ll see all of you in section 4, which is
the sequel to section 3: Advanced Digital Protection.