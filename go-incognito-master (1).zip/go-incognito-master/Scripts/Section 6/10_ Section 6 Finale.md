# Section 6 Finale

Welcome to the section 6 finale! It has been an absolute pleasure, and I hope this
section gave you insight into other things we need to do outside locking down
our devices and accounts. Privacy and security is a lifestyle that you need to live
and breathe everyday if you truly want to get the best out of it. We covered who
to trust, minimizing data access, anonymization and pseudonymisation,
shopping safely, lifestyle changes, pre-configured hardware & software, the
downsides to safety, and how to be an activist.

Remember, spread the message, and set the example. If we all play a part, we can
make a pretty big difference. Thanks for watching, and I’ll see you in section 7 to
wrap things up.