# Section 2 Finale

If you’ve gotten to this point, I want to personally congratulate you. These have
been your first steps to a more private and secure life, and it’s great to see
people take the plunge and make it happen.

In this section, we focused on minimalism and your digital footprint, which, in
itself is a very new concept to many of you. We talked about erasing your local
identity by removing unnecessary files and programs on your devices, and we
learned the basics of managing your online identity and what you can do to
minimize the amount of information that is publicly accessible about you online.

All very fun stuff!

If you haven’t already, consider supporting the course by purchasing it on Udemy
for an ad-free experience with quizzes, tests, checklists, and most importantly a
certificate! You can also help out by checking out all of the support methods,
which can be found on the course’s website and sharing it with the people you
know. Thanks to everyone in advance who helps out. You’re the ones who are
bringing this course to life.

Don’t forget to support the course by checking out all of the support methods
which can be found on the course’s website. Thanks in advance to everyone who
helps out, you’re the ones who are bringing this course to life.

Section 3: Basic Digital Protection, is Part 1 of 2 sections covering techniques that
you need to implement in order to avoid any future privacy and security invasion
(in the digital world) to maintain this clean slate you’ve worked so hard for. I will
see you there, thank you for watching, and good luck!