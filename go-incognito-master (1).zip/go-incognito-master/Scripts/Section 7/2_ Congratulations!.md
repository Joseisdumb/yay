# Congratulations!

This is it. I’m sad to be here saying goodbye, and it’s kind of crazy this entire
project has led to this point, it felt like it was never-ending. I honestly don’t have
much more to say. I want to thank you the viewer for being here today. Just
knowing that whoever is watching has been active in my community in some way,
shape, or form means a lot to me, it really does. Once again, don’t forget to
support the course, it’s completely free and public because of those of you who
are willing to give back, thank you to the supporters. I’m grateful everyday to be
able to do this for a living, and it’s something I hope to continue to do, and you’re
the people making that happen, so thank you.

I hope you’ve learned more than just a few things, I hope your life has completely
changed; if it did, please share your story with me because I’d love to hear it. That
is all I have to say, thank you for being a part of the course and the Techlore
community, and go out there and normalize privacy.
