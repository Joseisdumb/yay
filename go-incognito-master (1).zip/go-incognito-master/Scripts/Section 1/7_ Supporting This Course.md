# Supporting This Course

Congratulations, you have completed the introduction to the course! Before we
go into section 2 where we really start getting into the fun stuff, I wanted to
quickly ask for your help. My goal is to make this course public, accessible, and
free to everybody. and have a free variant for those who can’t afford the premium
version. More people need to be educated on security and privacy, and this is
how I believe I can contribute to the cause. This project has taken me well over
1000 hours to put together. So, if you want to support the course and the channel,
there are tons of ways you can do that, and I would really appreciate it.

First, there are lots of free ways you can help, at 0 cost to you. You can do all of
your Amazon shopping after clicking the Techlore Amazon affiliate link in the
support tab, so make sure to go through that next time you buy something on
Amazon, or better yet bookmark it. It won’t cost you a cent more, but some of that
purchase goes back to Techlore, which helps maintain the channel.

Another great way to help is by being a part of the community. Sharing the
course with your family and friends, keeping up with the YouTube videos, joining
Minds, joining the Discord, following Instagram; your support and contribution to
the community is just as important as any financial support.

Financially, there’s Bitcoin, Litecoin, ZenCash, and Monero addresses in the
support page which you can use to donate. If you are planning on creating a
Coinbase or Binance account, I have affiliate links for those, and if you buy $100
worth of bitcoin through Coinbase using the link there, you will get a free
additional $10 in BTC which is free money.

You can also purchase the course on Udemy, where there are lots of perks like
quizzes, tests, checklists, cool scoring games, no ads, and a certificate.

Lastly, don’t forget the swaggy merchandise on the Techlore store you can get to
show off your privacy and security, while spreading a good message to the
people around you.

So that’s going to wrap up Section 1 of the course. It’s a lot of talking, and not
much doing, but no longer. Section 2 will be geared towards erasing as much of
your public and private digital life as we possibly can, to offer as clean of a slate
as possible in order for us to really get down to business in section 3-7. Thank
you for watching up to this point, and I’m excited to work with every single one of
you in the future. I’ll see you in section 2: A Clean Slate.