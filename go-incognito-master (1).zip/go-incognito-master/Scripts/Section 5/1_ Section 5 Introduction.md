# Section 5 Introduction

Welcome to section 5 of Go Incognito: Physical Privacy and Security! Throughout
the section, you’re going to learn about the basics of physical protection, like
taping up webcams, disabling microphones, encrypting your devices, changing
Mac addresses, disabling radios on your devices, managing your routers, and
much more. I’ve shown this image before, but it’s more important than ever
because you can have the best encryption on the planet, but you’re as strong as
your weakest link. If a simple password is all that’s needed to break into your life,
then you’ve got a problem. Section 5 will teach you the physical side of things,
which is vital in our quest for privacy and security.

Before kicking off the first lesson, I want to say that I believe in every single one of
you watching this course. I know many things we’ve discussed have been heavy,
but I know all of you can do it. The last couple sections of the course are lighter
on technical information, so I’d say you’re through the toughest part, and it’s a
downhill race from here. Without further adieu, let’s get into the first lesson: The
Basics.